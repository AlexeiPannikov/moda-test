<template>
  <v-app class="h-screen d-flex">
    <header-layout />
    <v-main class="main">
      <router-view />
    </v-main>
  </v-app>
</template>

<script lang="ts" setup>
import HeaderLayout from './layouts/header-layout.vue';

</script>

<style lang="scss">
div, a {
  color: rgb(var(--v-theme-text-primary));
}

html {
  overflow: hidden;
}

.main {
  max-height: 100vh;
  flex-grow: 1;
}

.v-application__wrap {
  height: 100vh;
  min-height: auto !important;
  max-height: 100vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
</style>