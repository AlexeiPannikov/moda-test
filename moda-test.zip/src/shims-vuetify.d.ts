// declare module 'vuetify'
declare module 'vuetify/lib/components'
declare module 'vuetify/lib/directives'
