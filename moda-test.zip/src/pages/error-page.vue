
<template>
    <div class="error-page">
        404
    </div>
</template>

<script>
</script>

<style lang="scss">
.error-page {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    font-weight: bold;
}
</style>